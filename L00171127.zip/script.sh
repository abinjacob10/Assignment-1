#!/bin/bash

#This is a Linux script file which runs main.py, In Linux run this from present directory like this "./script.sh" 

python3 main.py
