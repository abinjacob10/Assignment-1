



def vendors(key1):
  
  dict1 ={
	"c8:4b:d6":"Dell",
	"18:68:cb":"Hikvision",
	"b8:27:eb":"Raspberry Pi",
	"c0:25:a5":"Dell",
	"a4:4c:c8":"Dell",
	"bc:5f:f4":"ASRock Incorporation"
       }
  value = dict1[key1]
  return value
